import razorpay
from flask import current_app

razorpay_client = razorpay.Client(auth=("YOUR_KEY_ID", "YOUR_KEY_SECRET"))

def create_order(amount, currency="INR"):
    data = {
        "amount": amount * 100,  # Razorpay expects amount in paise
        "currency": currency,
    }
    return razorpay_client.order.create(data=data)

def verify_payment(payment_id, order_id, signature):
    try:
        razorpay_client.utility.verify_payment_signature({
            'razorpay_payment_id': payment_id,
            'razorpay_order_id': order_id,
            'razorpay_signature': signature
        })
        return True
    except Exception:
        return False