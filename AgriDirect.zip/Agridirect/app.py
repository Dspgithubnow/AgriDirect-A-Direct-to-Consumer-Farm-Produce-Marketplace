
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, abort
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from models import db, init_db, User, Crop, CartItem, Purchase, Order
from razorpay_config import create_order, verify_payment
from flask_migrate import Migrate
from werkzeug.utils import secure_filename
import os
import random
import razorpay

# Razorpay configuration
RAZORPAY_KEY_ID = "rzp_test_zsGgUwgtPMathg"
RAZORPAY_KEY_SECRET = "WmhkMK7j84JuzhUCoJiCWUwD"
razorpay_client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///farm_fresh.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/crop_photos'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

init_db(app)
migrate = Migrate(app, db)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def home():
    crops = Crop.query.filter_by(approved=True).all()
    if current_user.is_authenticated:
        if current_user.user_type == 'farmer':
            return redirect(url_for('dashboard_farmer'))
        elif current_user.user_type == 'admin':
            return redirect(url_for('dashboard_admin'))
    return render_template('home.html', crops=crops)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        user_type = request.form.get('user_type')
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return redirect(url_for('register'))
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'error')
            return redirect(url_for('register'))
        user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password),
            user_type=user_type,
            balance=1000.0
        )
        db.session.add(user)
        db.session.commit()
        flash('Registration successful!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            flash('Logged in successfully!', 'success')
            if user.user_type == 'admin':
                return redirect(url_for('dashboard_admin'))
            elif user.user_type == 'farmer':
                return redirect(url_for('dashboard_farmer'))
            else:
                return redirect(url_for('dashboard_buyer'))
        flash('Invalid username or password', 'error')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully', 'success')
    return redirect(url_for('home'))

@app.route('/dashboard/farmer')
@login_required
def dashboard_farmer():
    if current_user.user_type != 'farmer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    crops = Crop.query.filter_by(farmer_id=current_user.id).all()
    return render_template('dashboard_farmer.html', crops=crops)

@app.route('/dashboard/buyer')
@login_required
def dashboard_buyer():
    if current_user.user_type != 'buyer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    crops = Crop.query.filter_by(approved=True).all()
    return render_template('home_buyer.html', crops=crops)

@app.route('/dashboard/admin')
@login_required
def dashboard_admin():
    if current_user.user_type != 'admin':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    pending_crops = Crop.query.filter_by(approved=False).all()
    approved_crops = Crop.query.filter_by(approved=True).all()
    return render_template('dashboard_admin.html', pending_crops=pending_crops, approved_crops=approved_crops)

@app.route('/add_crop', methods=['GET', 'POST'])
@login_required
def add_crop():
    if current_user.user_type != 'farmer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    if request.method == 'POST':
        name = request.form.get('name')
        price = float(request.form.get('price'))
        quantity = float(request.form.get('quantity'))
        description = request.form.get('description')
        photo_filename = None
        if 'photo' in request.files:
            photo = request.files['photo']
            if photo and photo.filename and allowed_file(photo.filename):
                filename = secure_filename(photo.filename)
                photo_filename = f"{current_user.id}_{int(datetime.utcnow().timestamp())}_{filename}"
                if not os.path.exists(app.config['UPLOAD_FOLDER']):
                    os.makedirs(app.config['UPLOAD_FOLDER'])
                photo.save(os.path.join(app.config['UPLOAD_FOLDER'], photo_filename))
        crop = Crop(
            name=name,
            price=price,
            quantity=quantity,
            description=description,
            photo_filename=photo_filename,
            farmer_id=current_user.id,
            approved=False
        )
        db.session.add(crop)
        db.session.commit()
        flash('Crop added successfully! Waiting for approval.', 'success')
        return redirect(url_for('dashboard_farmer'))
    return render_template('add_crop.html')

@app.route('/edit_crop/<int:crop_id>', methods=['GET', 'POST'])
@login_required
def edit_crop(crop_id):
    if current_user.user_type != 'farmer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    crop = Crop.query.get_or_404(crop_id)
    if crop.farmer_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard_farmer'))
    if request.method == 'POST':
        crop.name = request.form.get('name')
        crop.price = float(request.form.get('price'))
        crop.quantity = float(request.form.get('quantity'))
        crop.approved = False
        db.session.commit()
        flash('Crop updated successfully! Waiting for re-approval.', 'success')
        return redirect(url_for('dashboard_farmer'))
    return render_template('edit_crop.html', crop=crop)

@app.route('/delete_crop/<int:crop_id>', methods=['POST'])
@login_required
def delete_crop(crop_id):
    if current_user.user_type != 'farmer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    crop = Crop.query.get_or_404(crop_id)
    if crop.farmer_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard_farmer'))
    db.session.delete(crop)
    db.session.commit()
    flash('Crop deleted successfully', 'success')
    return redirect(url_for('dashboard_farmer'))

@app.route('/approve_crop/<int:crop_id>', methods=['POST'])
@login_required
def approve_crop(crop_id):
    if current_user.user_type != 'admin':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    crop = Crop.query.get_or_404(crop_id)
    crop.approved = True
    db.session.commit()
    flash('Crop approved successfully', 'success')
    return redirect(url_for('dashboard_admin'))

@app.route('/reject_crop/<int:crop_id>', methods=['POST'])
@login_required
def reject_crop(crop_id):
    if current_user.user_type != 'admin':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    crop = Crop.query.get_or_404(crop_id)
    db.session.delete(crop)
    db.session.commit()
    flash('Crop rejected and removed', 'success')
    return redirect(url_for('dashboard_admin'))


@app.route('/cancel_order/<int:order_id>', methods=['POST'])
@login_required
def cancel_order(order_id):
    order = Order.query.get_or_404(order_id)
    if order.buyer_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('my_orders'))
    if order.status in ['delivered', 'cancelled']:
        flash('This order cannot be cancelled', 'error')
        return redirect(url_for('my_orders'))
    try:
        crop = order.crop_ref
        crop.quantity += order.quantity
        order.status = 'cancelled'
        if order.purchase:
            order.purchase.payment_status = 'refunded'
        db.session.commit()
        flash('Order cancelled successfully', 'success')
    except Exception:
        db.session.rollback()
        flash('An error occurred while cancelling the order', 'error')
    return redirect(url_for('my_orders'))

@app.route('/my_orders')
@login_required
def my_orders():
    if current_user.user_type == 'buyer':
        orders = Order.query.filter_by(buyer_id=current_user.id).order_by(Order.created_at.desc()).all()
    elif current_user.user_type == 'farmer':
        orders = Order.query.join(Crop).filter(Crop.farmer_id == current_user.id).order_by(Order.created_at.desc()).all()
    else:
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    return render_template('my_orders.html', orders=orders)

@app.route('/update_order_status/<int:order_id>', methods=['POST'])
@login_required
def update_order_status(order_id):
    if current_user.user_type != 'farmer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    order = Order.query.get_or_404(order_id)
    if order.crop.farmer_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('my_orders'))
    new_status = request.form.get('status')
    order.status = new_status
    db.session.commit()
    flash('Order status updated successfully', 'success')
    return redirect(url_for('my_orders'))

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

@app.route('/cart')
@login_required
def view_cart():
    if current_user.user_type != 'buyer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    total = sum(item.crop.price * item.quantity for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total)

@app.route('/add_to_cart/<int:crop_id>', methods=['POST'])
@login_required
def add_to_cart(crop_id):
    if current_user.user_type != 'buyer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    quantity = int(request.form.get('quantity', 1))
    crop = Crop.query.get_or_404(crop_id)
    if quantity > crop.quantity:
        flash('Not enough quantity available!', 'error')
        return redirect(url_for('home'))
    cart_item = CartItem.query.filter_by(user_id=current_user.id, crop_id=crop_id).first()
    if cart_item:
        cart_item.quantity += quantity
    else:
        cart_item = CartItem(user_id=current_user.id, crop_id=crop_id, quantity=quantity)
        db.session.add(cart_item)
    db.session.commit()
    flash('Added to cart successfully!', 'success')
    return redirect(url_for('view_cart'))

@app.route('/remove_from_cart/<int:item_id>', methods=['POST'])
@login_required
def remove_from_cart(item_id):
    if current_user.user_type != 'buyer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    cart_item = CartItem.query.get_or_404(item_id)
    if cart_item.user_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('view_cart'))
    db.session.delete(cart_item)
    db.session.commit()
    flash('Item removed from cart!', 'success')
    return redirect(url_for('view_cart'))

@app.route('/razorpay_checkout_bulk', methods=['POST'])
@login_required
def razorpay_checkout_bulk():
    data = request.json
    try:
        razorpay_order_id = data['razorpay_order_id']
        razorpay_payment_id = data['razorpay_payment_id']
        razorpay_signature = data['razorpay_signature']

        # Step 1: Verify Signature
        razorpay_client.utility.verify_payment_signature({
            'razorpay_order_id': razorpay_order_id,
            'razorpay_payment_id': razorpay_payment_id,
            'razorpay_signature': razorpay_signature
        })

        razorpay_order = razorpay_client.order.fetch(razorpay_order_id)
        notes = razorpay_order.get('notes', {})
        buyer_id = int(notes['buyer_id'])
        address = notes['address']
        phone = notes['phone']
        cart_item_ids = list(map(int, notes['cart_item_ids'].split(',')))

        cart_items = CartItem.query.filter(CartItem.id.in_(cart_item_ids)).all()

        for item in cart_items:
            crop = Crop.query.get(item.crop_id)
            if item.quantity > crop.quantity:
                raise Exception(f"Not enough stock for {crop.name}")

            order = Order(
                buyer_id=buyer_id,
                crop_id=item.crop_id,
                quantity=item.quantity,
                total_amount=crop.price * item.quantity,
                payment_method='razorpay',
                delivery_address=address,
                contact_number=phone,
                status='confirmed',
                razorpay_order_id=razorpay_order_id,
                razorpay_payment_id=razorpay_payment_id
            )
            crop.quantity -= item.quantity
            db.session.add(order)
            db.session.flush()

            purchase = Purchase(
                order_id=order.id,
                transaction_id=razorpay_payment_id,
                payment_status='completed',
                amount=order.total_amount
            )
            db.session.add(purchase)
            db.session.delete(item)

        db.session.commit()
        return jsonify({'success': True})

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)})

@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    if current_user.user_type != 'buyer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))

    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    if not cart_items:
        flash('Your cart is empty', 'error')
        return redirect(url_for('view_cart'))

    total = sum(item.crop.price * item.quantity for item in cart_items)

    if request.method == 'POST':
        address = request.form.get('address')
        phone = request.form.get('phone')
        payment_method = request.form.get('payment_method')

        if not all([address, phone, payment_method]):
            flash('Please fill all fields.', 'error')
            return redirect(url_for('checkout'))

        if payment_method == 'cod':
            try:
                for cart_item in cart_items:
                    if cart_item.quantity > cart_item.crop.quantity:
                        flash(f"Not enough stock for {cart_item.crop.name}", 'error')
                        return redirect(url_for('checkout'))

                    order = Order(
                        buyer_id=current_user.id,
                        crop_id=cart_item.crop.id,
                        quantity=cart_item.quantity,
                        total_amount=cart_item.crop.price * cart_item.quantity,
                        payment_method='cod',
                        delivery_address=address,
                        contact_number=phone,
                        status='pending'
                    )
                    cart_item.crop.quantity -= cart_item.quantity
                    db.session.add(order)
                    db.session.delete(cart_item)

                db.session.commit()
                flash("Order placed successfully with Cash on Delivery.", "success")
                return redirect(url_for('my_orders'))

            except Exception as e:
                db.session.rollback()
                flash("Order failed: " + str(e), "error")
                return redirect(url_for('checkout'))

        elif payment_method == 'upi':
            try:
                amount_paise = int(total * 100)
                receipt_id = f"order_rcptid_{random.randint(1000, 9999)}"
                notes = {
                    'buyer_id': current_user.id,
                    'address': address,
                    'phone': phone,
                    'cart_item_ids': ','.join(str(item.id) for item in cart_items)
                }
                razorpay_order = razorpay_client.order.create({
                    "amount": amount_paise,
                    "currency": "INR",
                    "receipt": receipt_id,
                    "notes": notes
                })
                return render_template(
                    'razorpay_checkout.html',
                    cart_items=cart_items,
                    amount=amount_paise,
                    razorpay_order_id=razorpay_order['id'],
                    razorpay_key_id=RAZORPAY_KEY_ID,
                    buyer=current_user,
                    address=address,
                    phone=phone,
                    endpoint='/razorpay_checkout_bulk'  # <-- IMPORTANT
                )

            except Exception as e:
                flash("Error creating Razorpay order: " + str(e), "error")
                return redirect(url_for('checkout'))

        else:
            flash("Invalid payment method selected.", "error")
            return redirect(url_for('checkout'))

    return render_template('checkout.html', cart_items=cart_items, total=total)

@app.route('/create_payment_order', methods=['POST'])
@login_required
def create_payment_order():
    if current_user.user_type != 'buyer':
        return {'error': 'Access denied'}, 403
    amount = request.json.get('amount')
    order = create_order(amount)
    return jsonify(order)

@app.route('/mark_as_paid/<int:order_id>', methods=['POST'])
@login_required
def mark_as_paid(order_id):
    order = Order.query.get_or_404(order_id)
    if current_user.user_type != 'buyer' or order.buyer_id != current_user.id:
        flash('Access denied.', 'error')
        return redirect(url_for('my_orders'))
    if order.status == 'confirmed':
        flash('Order is already confirmed.', 'info')
        return redirect(url_for('my_orders'))
    order.status = 'confirmed'
    if not order.purchase:
        purchase = Purchase(
            order_id=order.id,
            payment_status='completed',
            transaction_id=f"UPI_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{current_user.id}",
            amount=order.total_amount
        )
        db.session.add(purchase)
    else:
        order.purchase.payment_status = 'completed'
    db.session.commit()
    flash('Payment marked as completed successfully.', 'success')
    return redirect(url_for('my_orders'))

@app.route('/buy_crop/<int:crop_id>', methods=['GET', 'POST'])
@login_required
def buy_crop(crop_id):
    if current_user.user_type != 'buyer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))

    crop = Crop.query.get_or_404(crop_id)

    if request.method == 'POST':
        try:
            quantity = float(request.form.get('quantity', 0))
            address = request.form.get('address')
            phone = request.form.get('phone')
            payment_method = request.form.get('payment_method')

            if quantity <= 0 or quantity > crop.quantity:
                flash('Invalid quantity or not enough stock', 'error')
                return redirect(url_for('buy_crop', crop_id=crop_id))

            if not all([address, phone, payment_method]):
                flash('Please fill in all required fields', 'error')
                return redirect(url_for('buy_crop', crop_id=crop_id))

            if payment_method == 'cod':
                # Cash On Delivery: Create Order and skip Razorpay
                order = Order(
                    buyer_id=current_user.id,
                    crop_id=crop.id,
                    quantity=quantity,
                    total_amount=crop.price * quantity,
                    payment_method='cod',
                    delivery_address=address,
                    contact_number=phone,
                    status='pending'
                )
                crop.quantity -= quantity
                db.session.add(order)
                db.session.commit()
                flash("Order placed successfully with Cash on Delivery.", "success")
                return redirect(url_for('my_orders'))

            elif payment_method == 'upi':
                # Razorpay payment: generate order and redirect to checkout template
                amount_paise = int(crop.price * quantity * 100)
                receipt_id = f"order_rcptid_{random.randint(1000,9999)}"
                notes = {
                    "buyer_id": current_user.id,
                    "crop_id": crop.id,
                    "quantity": quantity,
                    "address": address,
                    "phone": phone
                }

                razorpay_order = razorpay_client.order.create({
                    "amount": amount_paise,
                    "currency": "INR",
                    "receipt": receipt_id,
                    "notes": notes
                })

                return render_template(
                    'razorpay_checkout.html',
                    crop=crop,
                    amount=amount_paise,
                    razorpay_order_id=razorpay_order['id'],
                    razorpay_key_id=RAZORPAY_KEY_ID,
                    buyer=current_user,
                    address=address,
                    phone=phone,
                    quantity=quantity,
                    notes=notes,
                    endpoint='/razorpay_checkout'  # <-- IMPORTANT
                )

            else:
                flash("Invalid payment method selected.", "error")
                return redirect(url_for('buy_crop', crop_id=crop_id))
        except Exception as e:
            db.session.rollback()
            flash(f"Error processing order: {str(e)}", 'error')
            return redirect(url_for('buy_crop', crop_id=crop_id))

    return render_template('buy_crop.html', crop=crop)

@app.route('/razorpay_checkout', methods=['POST'])
@login_required
def razorpay_checkout():
    data = request.json
    try:
        razorpay_order_id = data['razorpay_order_id']
        razorpay_payment_id = data['razorpay_payment_id']
        razorpay_signature = data['razorpay_signature']

        # Step 1: Verify Razorpay Signature
        razorpay_client.utility.verify_payment_signature({
            'razorpay_order_id': razorpay_order_id,
            'razorpay_payment_id': razorpay_payment_id,
            'razorpay_signature': razorpay_signature
        })

        # Step 2: Fetch Razorpay order and notes
        razorpay_order = razorpay_client.order.fetch(razorpay_order_id)
        notes = razorpay_order.get('notes', {})
        buyer_id = int(notes['buyer_id'])
        crop_id = int(notes['crop_id'])
        quantity = float(notes['quantity'])
        address = notes['address']
        phone = notes['phone']

        crop = Crop.query.get(crop_id)
        if not crop:
            raise ValueError("Crop not found")

        # Step 3: Create Order and flush to get ID
        order = Order(
            buyer_id=buyer_id,
            crop_id=crop_id,
            quantity=quantity,
            total_amount=crop.price * quantity,
            payment_method='razorpay',
            delivery_address=address,
            contact_number=phone,
            status='confirmed'
        )
        crop.quantity -= quantity
        db.session.add(order)
        db.session.flush()  # <-- important

        # Step 4: Create Purchase with valid order_id
        purchase = Purchase(
            order_id=order.id,
            transaction_id=razorpay_payment_id,
            payment_status='completed',
            amount=crop.price * quantity
        )
        db.session.add(purchase)

        # Step 5: Commit both
        db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        print("Error in Razorpay checkout:", str(e))
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)})

@app.route('/admin/orders')
@login_required
def admin_orders():
    if current_user.user_type != 'admin':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('admin_orders.html', orders=orders)

@app.route('/update_upi_id', methods=['GET', 'POST'])
@login_required
def update_upi_id():
    if current_user.user_type != 'farmer':
        flash('Access denied', 'error')
        return redirect(url_for('home'))
    if request.method == 'POST':
        upi_id = request.form.get('upi_id')
        if upi_id:
            current_user.upi_id = upi_id
            db.session.commit()
            flash('UPI ID updated successfully!', 'success')
            return redirect(url_for('dashboard_farmer'))
    return render_template('update_upi_id.html')

if __name__ == '__main__':
    with app.app_context():
        '''db.drop_all()'''
        db.create_all()
        print("✅ Database reset successful.")

        inspector = db.inspect(db.engine)
        if 'upi_id' not in [col['name'] for col in inspector.get_columns('user')]:
            try:
                with db.session.begin():
                    db.session.execute('ALTER TABLE user ADD COLUMN upi_id VARCHAR(255)')
                db.session.commit()
            except Exception:
                db.session.rollback()
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@agridirect.com',
                password_hash=generate_password_hash('admin123'),
                user_type='admin',
                balance=0.0
            )
            db.session.add(admin)
            db.session.commit()
    app.run(debug=True)


