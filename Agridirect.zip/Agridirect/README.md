AgriDirect: A Direct-to-Consumer Farm Produce Marketplace

AgriDirect is a Flask-based web application that connects farmers, buyers, and admins on a unified platform. Farmers can list their produce, buyers can purchase directly using UPI or other methods, and admins approve crop listings and manage the platform.

Features

 Farmer Dashboard: Add, edit, delete crops; update UPI ID.

 Buyer Dashboard: Browse crops, manage cart, place orders via UPI or offline payment.

 Admin Dashboard: Approve/reject crop listings, view all orders.

 Authentication: Secure registration and login with hashed passwords.

 Payment Integration: UPI and Razorpay integration for online payments.

 Crop Image Upload: Farmers can upload images of their produce.

 Cart System: Buyers can add multiple items and checkout together.

 Order Management: Order tracking, cancellation, and delivery updates.

 Database: SQLite for local development; SQLAlchemy ORM used.

 Role-Based Access Control: Ensures only authorized users access certain routes.


Clone the Repository
bash

git clone https://github.com/Dspgithubnow/AgriDirect-A-Direct-to-Consumer-Farm-Produce-Marketplace
cd agridirect


Install Dependencies
Make sure Python (>=3.8) is installed.

pip install -r requirements.txt



Set Up the App
Run the application once to initialize the database and create the admin user:

bash

python app.py




├── app.py                  # Main Flask app
├── models.py               # SQLAlchemy models (User, Crop, Order, etc.)
├── razorpay_config.py      # Razorpay client configuration
├── static/
│   └── crop_photos/        # Uploaded crop images
├── templates/              # Jinja2 HTML templates
│   ├── home.html
│   ├── dashboard_admin.html
│   ├── dashboard_farmer.html
│   ├── login.html
│   └── ...
├── requirements.txt
└── README.md               # This file





